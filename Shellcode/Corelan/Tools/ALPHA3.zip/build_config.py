build_config = {
  "version": '1.0 alpha',
  "folders": [
    u'x64',
    u'x86'
  ]
}
