build_config = {
  "folders": [
    u'ascii_art',
    u'getpc',
    u'i32',
    u'rm32'
  ]
}
