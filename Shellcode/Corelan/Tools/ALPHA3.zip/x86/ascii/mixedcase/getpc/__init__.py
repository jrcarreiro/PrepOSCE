import countslide, seh;

encoders = countslide.encoders + seh.encoders;
