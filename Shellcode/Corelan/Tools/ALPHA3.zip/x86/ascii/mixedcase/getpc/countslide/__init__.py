import ALPHA3, i32, rm32

encoders = []
encoders.extend(rm32.encoders)
encoders.extend(i32.encoders)
