build_config = {
  "folders": [
    u'i32',
    u'rm32'
  ]
}
