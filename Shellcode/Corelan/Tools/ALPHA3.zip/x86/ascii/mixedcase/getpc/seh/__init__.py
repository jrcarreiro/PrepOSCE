import xpsp3

encoders = []
encoders.extend(xpsp3.encoders)
