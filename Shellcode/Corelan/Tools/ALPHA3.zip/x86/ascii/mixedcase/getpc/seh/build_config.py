build_config = {
  "folders": [
    u'xpsp3'
  ]
}
