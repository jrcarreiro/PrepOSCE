import rm32

encoders = rm32.encoders
for encoder in encoders:
  encoder["case"] = "uppercase"
