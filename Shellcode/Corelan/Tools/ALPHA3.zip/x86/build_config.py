build_config = {
  "version": '0.1 alpha',
  "folders": [
    u'utf_16',
    u'ascii',
    u'latin_1'
  ]
}
