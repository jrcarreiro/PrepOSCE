build_config = {
  "folders": [
    u'call'
  ]
}
