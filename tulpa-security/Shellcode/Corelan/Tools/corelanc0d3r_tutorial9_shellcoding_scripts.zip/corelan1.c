#include <windows.h>

int main(int argc, char** argv)
{
   MessageBox(NULL,
             "You have been pwned by Corelan",
			 "Corelan",
			 MB_OK);

}
